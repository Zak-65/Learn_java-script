# Online Courses Dashboard

A Pen created on CodePen.io. Original URL: [https://codepen.io/azrikahar/pen/abZzaga](https://codepen.io/azrikahar/pen/abZzaga).

This is a recreation of the free UI kit, Online Courses Dashboard by Chili Labs at https://dribbble.com/shots/10711741-Free-UI-Kit-for-Figma-Online-Courses-Dashboard